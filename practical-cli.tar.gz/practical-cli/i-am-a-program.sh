#!/bin/bash
#Pre-course challenge program

echo Welcome to the pre-course challenge
echo Please type in the one digit number of the second month of the year followed by enter
read numero
if [ $numero == "2" ]
then
	echo "Correct the number $numero is the one digit nuber for the second month of the year"
	echo "Now send a message through Slack to Pati Carvajal and tell her that you've completed the challenge and that today's date is"
	date
	echo "Don't forget to close the terminal and your VM!"

else
	echo Incorrect number, try running the program again!
fi
